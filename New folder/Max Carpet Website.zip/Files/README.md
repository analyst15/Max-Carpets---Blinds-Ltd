# Animated Under Construction Template

View the demo [here.](https://tmkamal.github.io/under-construction-template/)
``` 
Feel free to use this template for your upcoming projects.
```
This template has been built using SVG animation with CSS3.

## Preview

> Actual template is a lot smoother than this.  

![Preview](https://github.com/tmKamal/hosted-images/blob/master/under-construction/Document.gif?raw=true)<br/>  
